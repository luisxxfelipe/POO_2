
package atividade24;

import java.util.Scanner;

public class Atividade24 {

    public static void main(String[] args) {
       
        float n1, n2, resultado;
        int opcao;
        Scanner scan = new Scanner(System.in);
        
        System.out.println("\n**********BEM VINDO AO SISTEMA DE VERIFICACOES!***********\n");
        System.out.println("Insira dois valores para realizar as operacoes: ");
        n1 = scan.nextFloat();
        n2 = scan.nextFloat();
        
        do{
           
            System.out.println("\n\nEscolha alguma opcao:\n[1]Verificar se os numeros sao multiplos\n[2]Verificar se os numeros sao pares\n[3]Verificar se a media dos numeros >= 7\n[4]\n");
            opcao = scan.nextInt();
            
            switch (opcao) {
                case 1 -> {
                   if(n1 % n2 == 0){
                    System.out.println("Sao multiplos");
                    }
                   
                   else{
                       System.out.println("Nao sao multiplos");
                   }
                }
                case 2 -> {
                    resultado = n1 - n2;
                    System.out.println("O resultado sera: " + resultado);
                }
                case 3 -> {
                    resultado = n1 * n2;
                    System.out.println("O resultado sera: " + resultado);
                }
                default -> {
                }
            }
        }while(opcao != 4);
    }
    
}
