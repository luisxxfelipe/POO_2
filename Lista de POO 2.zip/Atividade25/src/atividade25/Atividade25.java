
package atividade25;

import java.util.Scanner;

public class Atividade25 {

    public static void main(String[] args) {
        float altura, resultado;
        int opcao;
        Scanner scan = new Scanner(System.in);
        
        System.out.println("\n**********BEM VINDO AO SISTEMA DE CALCULO DE PESO IDEAL!***********\n");
        System.out.println("Insira a sua altura: ");
        altura = scan.nextFloat();
        
        System.out.println("Digite [1] caso seja homem.\nDigite [2] caso seja mulher.\n");
        opcao = scan.nextInt();
        
        if(opcao == 1){
            resultado = (float) ((72.7 * altura) - 58);
            System.out.println("Seu peso ideal sera: " + resultado);
        }
        
        else if(opcao == 2){
            resultado = (float) ((62.1 * altura) - 44.7);
            System.out.println("Seu peso ideal sera: " + resultado);
        }
    }
    
}
