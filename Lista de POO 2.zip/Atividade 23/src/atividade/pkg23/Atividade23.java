
package atividade.pkg23;

import java.util.Scanner;

public class Atividade23 {

    public static void main(String[] args) {
        float n1, n2, resultado;
        int opcao;
        Scanner scan = new Scanner(System.in);
        
        System.out.println("\n**********BEM VINDO AO SISTEMA DE OPERACOES!***********\n");
        System.out.println("Insira dois valores para realizar as operacoes: ");
        n1 = scan.nextFloat();
        n2 = scan.nextFloat();
        
        do{
           
            System.out.println("\n\nEscolha alguma opcao:\n[1]Adicao\n[2]Subtracao\n[3]Multiplicacao\n[4]Divisao\n[5]Sair\n");
            opcao = scan.nextInt();
            
            switch (opcao) {
                case 1 -> {
                    resultado = n1 + n2;
                    System.out.println("O resultado sera: " + resultado);
                }
                case 2 -> {
                    resultado = n1 - n2;
                    System.out.println("O resultado sera: " + resultado);
                }
                case 3 -> {
                    resultado = n1 * n2;
                    System.out.println("O resultado sera: " + resultado);
                }
                case 4 -> {
                    resultado = n1 / n2;
                    System.out.println("O resultado sera: " + resultado);
                }
                default -> {
                }
            }
        }while(opcao != 5);
    }
    
}
