import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        double salario, reajuste;

        Scanner scan = new Scanner(System.in);

        System.out.println("Insira o valor atual do seu salario: ");
        salario = scan.nextDouble();

        System.out.println("Insira a porcentagem do reajuste: ");
        reajuste = scan.nextDouble();

        double reaj = REAJUSTE(salario, reajuste);

        System.out.println("O novo salario do trabalhador sera de " + reaj + " reais!");
    }

    private static double REAJUSTE(double n1, double n2) {

        double salario1 = (n1 * (n2 / 100));
        double salario = 0;
        salario = n1 + salario1 ;
        return salario;
    }
}