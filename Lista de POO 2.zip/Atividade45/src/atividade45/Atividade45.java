
package atividade45;

public class Atividade45 {

    public static void main(String[] args) {
        int i;
       
        for( i = 0; i < 10; i++){
            System.out.println(i + " ");
            
        }
       
        System.out.println("\n\nOrdem inversa: \n\n");
        
        for(int j = i; j >= 0;j--){
                System.out.println(j + " ");
            }
    }
    
}
