
package atividade.pkg12;

import java.util.Scanner;

public class Atividade12 {

    public static void main(String[] args) {
       
        int numero;
        
        Scanner scan = new Scanner(System.in);
       
        System.out.println("Digite um numero inteiro: ");
        numero = scan.nextInt();
        
        if(numero > 0){
            System.out.println("Modulo e o mesmo que o numero inteiro: " + numero);
        }
        
        else{
            
            int convertido = (numero *(-1));
            
            System.out.println("Numero inteiro menor que 0, seu modulo sera: " + convertido);
        }
    
    }
    
}
