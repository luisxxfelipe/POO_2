
package atividade3;

import java.util.Scanner;

public class Atividade3 {

    public static void main(String[] args) {
       
        char nome;
        int codigo, qtd_vendida;
        float preco, comissao, valor;
        
        Scanner scan = new Scanner(System.in); 
        
        System.out.println("\nBEM VINDO AO SISTEMA DE PAGAMENTO DE COMISSAO\n");
        System.out.println("Insira o nome do vendedor: ");
        nome = scan.next().charAt(0);
        
        System.out.println("Insira o codigo da peca: ");
        codigo = scan.nextInt();
        
        System.out.println("Insira o preco da peca vendida: ");
        preco = scan.nextFloat();
        
        System.out.println("Insira quantas pecas foram vendidas: ");
        qtd_vendida = (int) scan.nextFloat();
        
        valor = (preco * qtd_vendida);
        comissao = (float) (valor * 0.05);
        
        System.out.println("O vendedor " + nome + " recebeu de comissao R$" + comissao);
        
        
    }
    
}
