
package atividade46;

import java.util.Scanner;

public class Atividade46 {
    
    public static void main(String[] args) {
        
        Scanner scan = new Scanner(System.in);
        
        int [] vetorx = new int[10];
        int [] vetory= new int[10];
        
        for(int j = 0; j < 10;j++){
            System.out.println("Digite o "+(j+1)+"° numero do vetor x: ");
            vetorx[j] = scan.nextInt();
        }
        
        for(int i = 0; i < 10;i++){
            System.out.println("Digite o "+(i+1)+"° numero do vetor y: ");
            vetory[i] = scan.nextInt();
        }
        
        System.out.println("A multiplicacao dos vetores e: \n");
        
        for(int w = 0; w < 10;w++){
            System.out.println(vetorx[w] + " * "+ vetory[w]+ " = " +(vetory[w] * vetorx[w]));
            
        }
        
    }
    
}
