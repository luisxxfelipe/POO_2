import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int n1, n2;
        Scanner scan = new Scanner(System.in);


        System.out.println("Insira um valor para X e outro para Y: ");
        n1 = scan.nextInt();
        n2 = scan.nextInt();

        int verificador = VERIFICA_QUADRANTE(n1, n2);

        System.out.println("A coordenada [" + n1 + "]" + "[" + n2 + "] esta no quadrante -> " + verificador);
    }

    public static int VERIFICA_QUADRANTE(int x, int y){

        if (x > 0 && y < 0) return  1;
        else if (x > 0 && y > 0) {
            return  2;
        }
        else if (x < 0 && y < 0) {
            return  3;
        }
        else {
            return 4;
        }
    }

}