import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        float altura, base;

        Scanner scan = new Scanner(System.in);


        System.out.println("Insira o valor da altura do triangulo: ");
        altura = scan.nextFloat();

        System.out.println("Insira o valor da base do triangulo: ");
        base = scan.nextFloat();

        float hipt = HIPOTENUSA(altura, base);

        System.out.println("O valor da hipotenusa do triangulo sera: " + hipt);
    }

    private static float HIPOTENUSA(float altura, float base) {

        float area = (base * altura) /  2;
        return area;
    }
}