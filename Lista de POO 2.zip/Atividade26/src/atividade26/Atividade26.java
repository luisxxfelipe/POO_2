
package atividade26;

import java.util.Scanner;

public class Atividade26 {

    public static void main(String[] args) {
        
      for(int i = 100; i >= 0; i--){
          System.out.println(i + " ");
      }
}
}
