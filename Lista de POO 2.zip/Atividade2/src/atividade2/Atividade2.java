
package atividade2;

import java.util.Scanner;

public class Atividade2 {
    
    public static void main(String[] args) {
       float dolar, valor, conversao;
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Insira a cotacao do dolar hoje: ");
        dolar = scan.nextFloat();
        
        System.out.println("Insira um valor em dolares: ");
        valor = scan.nextFloat();
        
        conversao = (dolar * valor);
        
        System.out.println("O valor convertido em real sera de: " + conversao);
    }
}
