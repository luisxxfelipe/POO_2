
package atividade13;

import java.util.Scanner;

public class Atividade13 {

    public static void main(String[] args) {
        int n1, n2, n3;
        // 1 3 4
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Insira tres numeros inteiros: ");
        n1 = scan.nextInt();
        n2 = scan.nextInt();
        n3 = scan.nextInt();
        
        System.out.println("Os numeros em ordem decrescente ficam: ");
        
        if(n1 < n2){
            if(n2 < n3){
                System.out.println(n3 + "" + n2 + "" + n1);
            }
            
            else if(n1 < n3){
                System.out.println(n3 + "" + n1 + "" + n2);
            }
            else{
                System.out.println(n2 + "" + n1 + "" + n3);
            }
        } 
        
        else if(n2 > n3){
            if(n1 > n3){
                System.out.println(n1 + "" + n2 + "" + n3);
            }
            else{
                System.out.println(n2 + "" + n3 + "" + n1);
            }
        }
        
        else{
            System.out.println(n3 + "" + n2 + "" + n1);
        }
        
    }
   
    
}
