
package com.mycompany.atividade1;

import java.util.Scanner;

public class Atividade1 {

    public static void main(String[] args) {
        
        float qtd_min, qtd_max, med_estoque;
        
        Scanner scan = new Scanner(System.in);
      
        System.out.println("Insira a quantidade minima da peca: ");
        qtd_min = scan.nextFloat();
        
        System.out.println("Insira a quantidade maxima de peca: ");
        qtd_max = scan.nextFloat();
        
        med_estoque = (qtd_min + qtd_max) / 2;
        
        System.out.println("O estoque medio da peca informada sera de: "+ med_estoque);
    }
}
