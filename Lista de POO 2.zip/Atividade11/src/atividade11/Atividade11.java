
package atividade11;

import java.util.Scanner;

public class Atividade11 {

    public static void main(String[] args) {
        
        int a, b, x;
        
        Scanner scan = new Scanner(System.in);
       
       System.out.println("Insira o valor de A: ");
       a = scan.nextInt();
       System.out.println("Insira o valor de B: ");
       b = scan.nextInt();
       
       x = a;
       a = b;
       b = x;
       
       System.out.println("O valor de A passou a ser: " + a + ", o valor de B passou a ser: " + b);
    }
    
}
