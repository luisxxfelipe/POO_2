import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        int[] vetor = new int[10];

        int x, maiores = 0, menores = 0, iguais = 0;

        // leitura do vetor

        System.out.println("Digite os 10 números do vetor:");
        for (int i = 0; i < 10; i++) {
            vetor[i] = input.nextInt();
        }

        // leitura do número x
        System.out.println("Digite um número inteiro positivo:");
        x = input.nextInt();

        // contagem dos números maiores, menores e iguais a x
        for (int i = 0; i < 10; i++) {
            if (vetor[i] > x) {
                maiores++;
            } else if (vetor[i] < x) {
                menores++;
            } else {
                iguais++;
            }
        }

        // exibição dos resultados
        System.out.println("Quantidade de números maiores que " + x + ": " + maiores);
        System.out.println("Quantidade de números menores que " + x + ": " + menores);
        System.out.println("Quantidade de números iguais a " + x + ": " + iguais);

        input.close();
    }
}
